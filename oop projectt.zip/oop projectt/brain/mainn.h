using namespace std;
class mainn
{
public:
    void mainfunc();
    void make();
    void make2();
};
