#define MASTER_HEADER_FILE
using namespace std;
#include <iostream>
#include <string>
#include <iostream>
#include <fstream>
#include <conio.h>
#include <string>
#include <vector>
#include <map>
#include <algorithm>
#include "data/data_header.h"
#include "brain/brain_header.h"
#include "interface/interface_header.h"
