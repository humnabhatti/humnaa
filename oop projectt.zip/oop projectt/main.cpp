#include "./master_header.h"

int main()
{

    interfacee INTERFACEE;
    INTERFACEE.draw();
    INTERFACEE.data();
}