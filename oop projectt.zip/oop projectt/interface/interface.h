using namespace std;
class interfacee
{
    public:
    void draw();
    void data();

};