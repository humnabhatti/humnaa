
using namespace std;
class makeover
{
public:
    int DIOR[200];
    int FIT_ME[200];
    int HUDA_BEAUTY[200];
    int LAKME[200];
    int MEDORA[200];
    int MAC_LIPSTICKS[200];
    int LAKME_LIPSTICKS[200];
    int MAYBELLINE[200];
    int RED[200];
    int YELLOW[200];
    int BLACK[200];
    int PINK[200];
    int MAYBELLINE_BLUSH_ON[200];
    int HUDA_BEAUTY_BLUSH_ON[200];
    int RARE_BEAUTY[200];
    int KYLIE[200];
    int MAYBELLINE_HIGHLIGHTERS[200];
    int HUDA_BEAUTY_HIGHLIGHTERS[200];
    int RAREBEAUTY_HIGHLIGHTERS[200];
    int KYLIE_HIGHLIGHTERS[200];
    void viewFOUNDATION(char item);
    void viewLIPSTICK(char item);
    void viewNAILPOLISH(char item);
    void viewBLUSHON(char item);
    void viewHIGHLIGHTER(char item);
    void makeup();
    makeover();
    void physicalMakeup();
};