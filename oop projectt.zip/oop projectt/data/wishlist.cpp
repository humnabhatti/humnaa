#include "data_header.h"

using namespace std;

wishlist::wishlist(string name, float price, int quant)
{
    itemName = name;
    itemPrice = price;
    quantity = quant;
};
