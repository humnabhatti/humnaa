#ifndef DATA_HEADER_h
#define DATA_HEADER_h

#include <iostream>
#include <fstream>
#include <conio.h>
#include <string>
#include <vector>
#include <map>
#include <algorithm>
#include "sign.h"
#include "login.h"
#include "cart.h"
#include "wishlist.h"
#include "Shoppingcart.h"
#include "household.h"
#include "makeover.h"
#include "bakery.h"
#include "washroom.h"
#endif