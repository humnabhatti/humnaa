using namespace std;
class household
{
public:
    int DALDA[200];
    int CANOLA[200];
    int MEEZAN[200];
    int SUFI[200];
    int FALAK_PREMIUM[200];
    int BASMATI[200];
    int GUARD[200];
    int KING[200];
    int SUNRIDGE[200];
    int BAKEPARLOR[200];
    int RAFHAN[200];
    int FAUJI[200];
    int BROWNSUGAR[200];
    int EATING_PURE[200];
    int CHASHNIK[200];
    int AMNA[200];
    int LIPTON[200];
    int DANEDAR[200];
    int TEZDUM[200];
    int VITAL[200];
    int KNOR[200];
    int SHOOP[200];
    int MAGGI[200];
    int KELLOGG[200];
    void viewOIL(char item);
    void viewRICE(char item);
    void viewFLOUR(char item);
    void viewSUGAR(char item);
    void viewTEA(char item);
    void viewNOODLES(char item);
    household();
    void grocery();
    void physicalGrocery();
};