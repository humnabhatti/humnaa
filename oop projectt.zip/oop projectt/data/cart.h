using namespace std;
class CartItem
{
public:
    string itemName;
    float itemPrice;
    int quantity;
    CartItem(string name, float price, int quant);
};