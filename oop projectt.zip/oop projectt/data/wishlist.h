#include <string>
using namespace std;
class wishlist
{
public:
     string itemName;
    float itemPrice;
    int quantity;

    wishlist(string name, float price, int quant);
};
