
using namespace std;
class login
{
public:
    void authentic();
    void handlePasswordRecovery(const string &username);
};
