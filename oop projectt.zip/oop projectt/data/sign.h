

using namespace std;
class sign_up
{
    public:
    string name;
    string phone_no;
    string username;
    string password;
    string gmail;

    sign_up();
    void saveToFile();
    void getdata();
    string maskedInput();
};
