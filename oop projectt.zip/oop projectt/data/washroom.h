using namespace std;
class washroom
{
public:
    int COLGATE[200];
    int SENSODYNE[200];
    int MEDICAM[200];
    int AQUAFRESH[200];
    int TIDE[200];
    int PERSIL[200];
    int GAIN[200];
    int ARIEL[200];
    int DOVE[200];
    int PALMOLIVE[200];
    int SAFEGUARD[200];
    int LUX[200];
    int VINCE[200];
    int GOLDENPEARL[200];
    int POUNDS[200];
    int CARE[200];
    washroom();
    void viewTOOTHPASTE(char item);
    void viewDETERGENT(char item);
    void viewSOAP(char item);
    void viewFACEWASH(char item);
    void washroom_equipments();
};